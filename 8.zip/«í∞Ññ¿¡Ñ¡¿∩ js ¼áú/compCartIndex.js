Vue.component('mycart', {

    template: `
        <div class="card">
            <article class="card">
                <div class="content__card" @click="$parent.addProduct(item), $root.counter++"
                v-for="item of $parent.filtered" :key="item.id_product">
                <img class="card__hover" :src="item.imgHover" alt="hover">
                <img class="card__img" :src="item.img" alt="ELLERY X M'O CAPSULE">
                <div class="content__text">
                    <div class="content__text">
                        <h3 class="zag__card">{{item.tittle}}</h3>
                        <p class="p__card">{{item.text}}</p>
                        <div class="price">\${{item.price}}</div>
                    </div>
                </div>
            </div>                                
        </article>
    </div>
`
})