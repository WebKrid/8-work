Vue.component('basket', {

    template: `
    <div class="cart-block">
        <p v-if="$parent.basketItems.length === 0">Cart is empty</p>
        <div class="basketItem" v-for="item of $parent.basketItems"
            :key="item.id_product">
            <img :src="item.img" width="120px" alt="Some img">
            <div class="product-title">{{ item.tittle }}</div>
            <div class="product-quantity">{{ item.quantity
                }}</div>
            <div class="product-single-price">$ {{ item.price }}
            </div>
            <div class="product-price">{{item.quantity*item.price}}
            </div>
            <button class="del-btn"
                @click="$parent.remove(item), $root.counter--">X</button>
        </div>
    </div>
`
})