const API = 'https://raw.githubusercontent.com/GeekBrainsTutorial/online-store-api/master/responses';


const app = new Vue({
    el: '#app',

    data: {
        userSearch: '',
        show: false,
        counter: 0,
        catalogUrl: `indexCart.json`,
        cartUrl: `cartBasket.json`,
        cartIndex: [],
        filtered: [],
        basketItems: [],
        // cartCatalog: [],
    },
    methods: {
        getJson(url) {
            return fetch(url)
                .then(result => result.json())
                .catch(error => console.log(error))
        },
        addProduct(item) {
            this.getJson(`${API}/addToBasket.json`)
                .then(data => {
                    if (data.result === 1) {
                        let find = this.basketItems.find(el => el.id_product === item.id_product);
                        if (find) {
                            find.quantity++;
                        } else {
                            const prod = Object.assign({ quantity: 1 }, item);
                            this.basketItems.push(prod)
                        }
                    }
                })
        },
        remove(item) {
            this.getJson(`${API}/addToBasket.json`)
                .then(data => {
                    if (data.result === 1) {
                        if (item.quantity > 1) {
                            item.quantity--;
                        } else {
                            this.basketItems.splice(this.basketItems.indexOf(item), 1);
                        }
                    }
                })
        },
        filter() {
            let regexp = new RegExp(this.userSearch, 'i');
            this.filtered = this.cartIndex.filter(item => regexp.test(item.tittle));
        }
    },
    mounted() {
        this.getJson(`cartBasket.json`)
            .then(data => {
                for (let item of data) {
                    this.basketItems.push(item);
                }
            });
        this.getJson(`indexCart.json`)
            .then(data => {
                for (let item of data) {
                    this.$data.cartIndex.push(item);
                    this.$data.filtered.push(item);
                }
            })
    },

});





