let fs = require('fs');
let cartIndex = [{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_1(men).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},
{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_2 (women).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},
{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_3(men_2).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},
{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_4(men_3).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},
{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_5(women_2).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},
{
    imgHover: 'img/Hover_card.png',
    img: 'img/card_6(women_3).jpg',
    tittle: "ELLERY X M'O CAPSULE",
    text: "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
    price: '52.00',
},

];
fs.writeFile('indexCart.json', JSON.stringify(cartIndex), err => {
    if (err) {
        console.log(err);
    }
})