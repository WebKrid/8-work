let fs = require('fs');
let carts = [
    {
        number: 0,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_1(men).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 1,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_2(men_2).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 2,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_3(men_2).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 3,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_4(men_3).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 4,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_5(men_5).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 5,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_6(men_6).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 6,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_7(men_7).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 7,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_8(men_8).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
    {
        number: 8,
        imghover: "img/Hover_card.png",
        hover: "hover",
        img: "img/card_9(men_9).jpg",
        h3: "ELLERY X M'O CAPSULE",
        p: 'Known for her sculptural takes on traditional tailoring,Australian arbiter of cool Kym Ellery teams up with Moda Operandi.',
        price: 52.00,
    },
];

fs.writeFile('cards.json', JSON.stringify(carts), err => {
    if (err) {
        console.log(err);
    }
});