'use strict';

let cards = document.querySelectorAll('.content__card');

function addEventListenerForAddCard() {
    cards.forEach(function (card) {
        card.addEventListener('click', addedProductHandler);
    });
}


function addedProductHandler(event) {
    const productId = event.currentTarget.getAttribute('number');
    addProductIntoBasket(productId);
}

addEventListenerForAddCard();
