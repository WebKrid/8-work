'use strict';

const openBasketBtn = document.querySelector('.header__item__open');
const basketEl = document.querySelector('.basket');
const basketCounterEl = document.querySelector('.cartIconWrap_span');
const basketTotalEl = document.querySelector('.basketTotal');
const basketTotalValueEl = document.querySelector('.basketTotalValue');
const basketDeleteEl = document.querySelector('.product_delete');

function increaseProductsCount() {
    basketCounterEl.textContent++;
}

function addProductIntoBasket(productId) {
    increaseProductsCount();
    addProductToObject(productId);
    renderProduktInBasket(productId);
    calculateAndRenderTotalBasketSum();
}

let basket = {};

function addProductToObject(productId) {
    if (!(productId in basket)) {
        basket[productId] = 1;
    } else {
        basket[productId]++;
    }
}

function renderProduktInBasket(productId) {
    let productExist = document.querySelector(`.productCount[number = '${productId}']`);
    if (productExist) {
        increaseProductCount(productId);
        recalculateSumForProduct(productId);
    } else {
        renderNewProductInBasket(productId);
    }
}
openBasketBtn.addEventListener('click', function () {
    basketEl.classList.toggle('hidden');
})

function renderNewProductInBasket(productId) {
    let productRow = `
    <div class="basketRow">
    <div>${cards[productId].querySelector('.zag__card').textContent}</div>
    <div>
    <span class="productCount" number="${productId}">1</span> шт.
    </div>
    <div>$${cards[productId].querySelector('.price__num').textContent}</div>
    <div>
    $<span class="productTotalRow" number="${productId}">${cards[productId].querySelector('.price__num').textContent}</span>
    </div>
    <button class="product_delete '${cards[productId]}'" submit.prevent>Удалить</button>
    `;
    basketTotalEl.insertAdjacentHTML('beforebegin', productRow);
}

function increaseProductCount(productId) {
    const productCountEl = document.querySelector(`.productCount[number="${productId}"]`);
    productCountEl.textContent++;
}

function recalculateSumForProduct(productId) {
    const productTotalRowEl = document.querySelector(`.productTotalRow[number = '${productId}']`);
    let totalPriceForRow = (basket[productId] * cards[productId].querySelector('.price__num').textContent).toFixed(2);
    productTotalRowEl.textContent = totalPriceForRow;
}

function calculateAndRenderTotalBasketSum() {
    let totalSum = 0;
    for (let productId in basket) {
        totalSum += basket[productId] * cards[productId].querySelector('.price__num').textContent;
    }
    basketTotalValueEl.textContent = totalSum.toFixed(2);
}
document.onclick = event => {
    if (event.target.classList.contains('product_delete')) {
        // DeleteEl(event.target)
        console.log(event.target.classList)
    }
}

// const DeleteEl = target => {
//     [object]++;
// }